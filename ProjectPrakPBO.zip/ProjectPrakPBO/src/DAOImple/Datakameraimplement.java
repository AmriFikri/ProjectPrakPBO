/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImple;
import java.util.List;
import model.*;
/**
 *
 * @author Lenovo
 */
public interface Datakameraimplement {
    public void insert(datakamera m);
    public void update(datakamera m);
    public void delete(int id_data);
    public List<datakamera> getALL();
}
