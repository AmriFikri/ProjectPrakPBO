package kamera;


public class Kamera {

    public static void main(String[] args) {
        MainView v = new MainView();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
}
