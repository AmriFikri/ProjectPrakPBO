/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.*;
import DAO.datakameraDAO;
import DAOImple.Datakameraimplement;
import javax.swing.JOptionPane;
import model.*;
import kamera.MainView;
/**
 *
 * @author Lenovo
 */
public class datakameracontroller {
    MainView frame;
    Datakameraimplement impdatakamera;
    List<datakamera> dm;
    
    public datakameracontroller(MainView frame){
    this.frame = frame;
    impdatakamera = new datakameraDAO();
    dm = impdatakamera.getALL();
    }
    public void isitabel (){
        dm = impdatakamera.getALL();
        modeltabelkamera mm = new modeltabelkamera(dm);
        frame.getTabeldatakamera().setModel(mm);
    }
    
 public void insert(){
     datakamera dm = new datakamera();
     dm.setNama(frame.getNama().getText());
     String selectedKamera = (String) frame.getKamera().getSelectedItem();
     dm.setKamera(selectedKamera);
     String tarif = frame.getTharga().getText();
     dm.setTarif(Integer.parseInt(tarif));
     String lama = frame.getLama().getText();
     dm.setLama_sewa(Integer.parseInt(lama));
     String total = frame.getTotal().getText();
     dm.setHarga_total(Integer.parseInt(total));
     impdatakamera.insert(dm);
     
    }
 
 public void update() {
    try {
        datakamera dm = new datakamera();
        dm.setNama(frame.getNama().getText());
        
        String selectedKamera = (String) frame.getKamera().getSelectedItem();
        dm.setKamera(selectedKamera);

        String tarif = frame.getTharga().getText();
        if (tarif.isEmpty()) {
            throw new IllegalArgumentException("Tarif tidak boleh kosong");
        }
        dm.setTarif(Integer.parseInt(tarif));

        String lama = frame.getLama().getText();
        if (lama.isEmpty()) {
            throw new IllegalArgumentException("Jumlah tidak boleh kosong");
        }
        dm.setLama_sewa(Integer.parseInt(lama));

        String total = frame.getTotal().getText();
        if (total.isEmpty()) {
            throw new IllegalArgumentException("Total tidak boleh kosong");
        }
        dm.setHarga_total(Integer.parseInt(total));

        String idDataStr = frame.getId_data().getText();
        if (idDataStr.isEmpty()) {
            throw new IllegalArgumentException("ID data tidak boleh kosong");
        }
        dm.setId_data(Integer.parseInt(idDataStr));

        impdatakamera.update(dm);
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Input tidak valid: " + ex.getMessage(), "Kesalahan Input", JOptionPane.ERROR_MESSAGE);
    } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Kesalahan Input", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + ex.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace(); // Menambahkan pencatatan pengecualian ke dalam log
    }
}

  public void delete(){
int id_data = Integer.parseInt(frame.getId_data().getText());
impdatakamera.delete(id_data);

    }

}
