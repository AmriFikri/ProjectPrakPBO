/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import DAOImple.Datakameraimplement;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Lenovo
 */
public class datakameraDAO implements Datakameraimplement{
    Connection connection;
    
    final String select = "SELECT * FROM data";
    final String insert = "INSERT INTO data (id_data,nama,kamera,tarif,lama_sewa,harga_total) VALUES (?, ?, ?, ?,?,?)";
    final String update = "UPDATE data set  nama=?,kamera=?,tarif=?,lama_sewa=?,harga_total=? where id_data=?";
    final String delete = "DELETE from data where id_data=?";
    public datakameraDAO(){
        connection = connector.connection();
        
    }

    @Override
    public void insert(datakamera m) {
     PreparedStatement statement = null;
        try {
         
            statement = connection.prepareStatement(insert, statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, m.getId_data());
            statement.setString(2, m.getNama());
            statement.setString(3, m.getKamera());
            statement.setInt(4, m.getTarif());
            statement.setInt(5, m.getLama_sewa());
            statement.setInt(6, m.getHarga_total());
          
            statement.executeUpdate();
            ResultSet re = statement.getGeneratedKeys();
            while(re.next()){
                m.setId_data(re.getInt(1));
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
            ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(datakamera m) {
         PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(update, statement.RETURN_GENERATED_KEYS);
statement.setString(1, m.getNama());
statement.setString(2, m.getKamera());
statement.setInt(3, m.getTarif());
statement.setInt(4, m.getLama_sewa());
statement.setInt(5, m.getHarga_total());
statement.setInt(6, m.getId_data());

            statement.executeUpdate();
            ResultSet re = statement.getGeneratedKeys();
            
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
            ex.printStackTrace();
            }
        }
    }
    
    

    @Override
    public List<datakamera> getALL() {
        List<datakamera> dm = null;
        try{
            dm = new ArrayList<datakamera>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()){
                datakamera kamera = new datakamera ();
          
            kamera.setId_data(rs.getInt("id_data"));
            kamera.setNama(rs.getString("nama"));
            kamera.setKamera(rs.getString("kamera"));
            kamera.setTarif(rs.getInt("tarif"));
            kamera.setLama_sewa(rs.getInt("lama_sewa"));
            kamera.setHarga_total(rs.getInt("harga_total"));
                dm.add(kamera);
            }
        }catch(SQLException ex){
            Logger.getLogger(datakameraDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        return dm;
    }
    @Override
     public void delete(int id_data) {
        PreparedStatement statement = null;
        try { 
            statement = connection.prepareStatement(delete, statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, id_data);
            statement.executeUpdate();
            ResultSet re = statement.getGeneratedKeys();
            
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
            ex.printStackTrace();
            }
        }
    }

    
    }

    
    

